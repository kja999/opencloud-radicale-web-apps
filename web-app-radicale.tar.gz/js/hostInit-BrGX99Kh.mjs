const i=await import("./remoteEntry-Bf2dTlph.mjs");await i.init();
